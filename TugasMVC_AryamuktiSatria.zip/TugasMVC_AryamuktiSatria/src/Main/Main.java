package Main;

import View.Dosen.ViewData;

public class Main {

    public static void main(String[] args) {
        new ViewData();
    }
    
}
